import React from 'react'

const PartnerShips = () => {
  return (
       <div>
            <div className='container-fluid partnershiphead mb-3 mt-3'>
                 <div className='overlay'></div>
                 <div className='row h-100'>
                      <div className='col-md-4'></div>
                      <div className='col-md-4 text-center text-light my-auto headtext text-uppercase'>Partnerships</div>
                      <div className='col-md-4'></div>
                 </div>
            </div>
       </div>
  );
}

export default PartnerShips
